# IAJR Buscador — Android

Proyecto Android que empaqueta `jr-buscador-v5-promo-style.html` como una aplicación instalable mediante WebView.

## Nombre
IAJR Buscador

## Paquete
`com.iajr.buscador`

## Compilar APK
Requiere Android SDK, JDK 17 y Gradle 8.x.

### Desde Android Studio
1. Abre esta carpeta como proyecto.
2. Espera a que Gradle sincronice.
3. Ejecuta **Build > Build APK(s)**.
4. El APK de depuración quedará en `app/build/outputs/apk/debug/app-debug.apk`.

### En GitHub Actions
El repositorio incluye `.github/workflows/build-apk.yml`, que instala el SDK necesario y genera el APK automáticamente.
